package com.ocp.day24;
public class John extends Thread{
 public void run(){
  System.out.println("寫程式");   
 }
}
