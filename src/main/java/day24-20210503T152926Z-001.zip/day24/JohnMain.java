package com.ocp.day24;
public class JohnMain {
public static void main(String[] args) {
John  john = new John();
john.start();
    }
    
}
